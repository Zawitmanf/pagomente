<?php


error_reporting();
session_start();

?>